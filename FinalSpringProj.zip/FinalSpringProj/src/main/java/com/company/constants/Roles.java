package com.company.constants;

public enum Roles {
	ROLE_USER,ROLE_ADMIN;
}
