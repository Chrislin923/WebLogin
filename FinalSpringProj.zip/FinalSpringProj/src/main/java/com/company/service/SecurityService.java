package com.company.service;

public interface SecurityService {
	void autoLogin(String username, String password);
}
